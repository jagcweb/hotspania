<div class="modal fade" id="editar-status-<?php echo e($u->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h4 class="modal-title" id="myCenterModalLabel">Editar status <?php echo e($u->full_name); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body p-4">

                <form method="POST" action="<?php echo e(route('admin.users.update_status')); ?>" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="active" name="active" value="1" <?php if($u->active == 1): ?> checked <?php endif; ?>/>
                        <label class="form-check-label" for="active">
                            ¿Cuenta activa?
                        </label>  
                    </div>

                    <div class="form-check mt-2">
                        <input class="form-check-input" type="checkbox" id="frozen" name="frozen" value="1" <?php if($u->frozen == 1): ?> checked <?php endif; ?>/>
                        <label class="form-check-label" for="frozen">
                            ¿Cuenta congelada?
                        </label>  
                    </div>
        
                    <div class="form-check mt-2">
                        <input class="form-check-input" type="checkbox" id="visible" name="visible" value="1" <?php if($u->visible == 1): ?> checked <?php endif; ?>/>
                        <label class="form-check-label" for="visible">
                            ¿Cuenta visible?
                        </label>  
                    </div>

                    <input type="text" hidden name="user_id" value="<?php echo e($u->id); ?>" />

                    <div class="form-group mt-2">
                        <input type="submit" class="btn btn-sm btn-dark waves-effect waves-dark w-100" style="line-height: 10px;" value="Actualizar"/>
                    </div>
                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal --><?php /**PATH /var/www/vhosts/41031227.servicio-online.net/hotspania.es/resources/views/modals/admin/user/modal_editar_status.blade.php ENDPATH**/ ?>