<div class="modal fade" id="tags-<?php echo e($u->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h4 class="modal-title" id="myCenterModalLabel">Tags <?php echo e($u->full_name); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body p-4">

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal --><?php /**PATH /var/www/vhosts/41031227.servicio-online.net/hotspania.es/resources/views/modals/admin/user/modal_tags.blade.php ENDPATH**/ ?>