

<?php $__env->startSection('title'); ?> Cambiar de Ciudad <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <h5 class="w-100 text-center mt-2">Cambiar de ciudad</h5>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12">
                        <form method="POST" action="<?php echo e(route('admin.citychanges.apply')); ?>" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="zone" class="form-label">Ciudad</label>
                                <select class="form-control" id="city_id" name="city" required>
                                    <option hidden selected disabled>
                                        Escoge una ciudad...
                                    </option>
                                    <option value="todas">Todas</option>
                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e(strtolower($c->name)); ?>"><?php echo e($c->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <p>Ciudad Actual: <?php echo e(!is_null(\Cookie::get('city')) ? ucfirst(\Cookie::get('city')) : 'Ninguna ciudad seleccionada. Por defecto: Barcelona'); ?></p>
                              <button type="submit" class="btn">Aplicar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Bootstrap Tables js -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/41031227.servicio-online.net/hotspania.es/resources/views/admin/citychanges/index.blade.php ENDPATH**/ ?>