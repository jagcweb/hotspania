<?php if(Session::has('error')): ?>
    <div style="z-index:999; position:fixed; top:10%; width:100%; display:flex; justify-content:center; align-items:center; min-height:50px; background:red; color:#fff; text-align:center; font-size:16px;">
        <?php echo e(Session::get('error')); ?>

        <?php
            Session::forget('error');
        ?>
    </div>
<?php endif; ?>

<?php if(Session::has('exito')): ?>
    <div style="z-index:999; position:fixed; top:10%; width:100%; display:flex; justify-content:center; align-items:center; min-height:50px; background:green; color:#fff; text-align:center; font-size:16px;">
        <?php echo Session::get('exito'); ?>

        <?php
            Session::forget('exito');
        ?>
    </div>
<?php endif; ?>

<?php if(count($errors) > 0): ?>
    <div style="z-index:999; position:fixed; top:10%; width:100%; display:flex; justify-content:center; align-items:center; min-height:50px; background:red; color:#fff; text-align:center; font-size:16px;">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?><?php /**PATH /var/www/vhosts/41031227.servicio-online.net/hotspania.es/resources/views/partial_msg.blade.php ENDPATH**/ ?>