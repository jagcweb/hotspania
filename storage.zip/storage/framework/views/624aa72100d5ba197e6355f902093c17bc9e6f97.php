

<?php $__env->startSection('title'); ?> Fichas pendientes <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <h5 class="w-100 text-center mt-2">Fichas Pendientes en <b><?php echo e(ucfirst(\Cookie::get('city')) ?? 'Barcelona'); ?></b></h5>
            <div class="card-body">
                <table class="table mt-4">
                    <thead>
                      <tr>
                        <th>Nombre</th>
                        <th>Ficha</th>
                        <th>DNI</th>
                        <th>Telefono</th>
                        <th>Ciudades</th>
                        <th>¿Completado?</th>
                        <th>Visible</th>
                        <th>Online</th>
                        <th>Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(\Cookie::get('city') != "todas"): ?>
                                <?php 
                                    $city = \App\Models\City::where('name', \Cookie::get('city') ?? 'Barcelona')->first();
                                    $city_user = \App\Models\CityUser::where('user_id', $u->id)->where('city_id', $city->id)->first(); 
                                ?>
                            <?php else: ?>
                                <?php $city_user = null; ?>
                            <?php endif; ?>
                            <?php if(is_object($city_user) || \Cookie::get('city') == "todas"): ?>
                                <tr>
                                    <td><?php echo e($u->full_name); ?></td>
                                    <td><?php echo e($u->nickname); ?></td>
                                    <td><?php echo e($u->dni); ?></td>
                                    <td><?php echo e($u->phone); ?></td>
                                    <?php $cities = \App\Models\CityUser::where('user_id', $u->id)->get(); ?>
                                    <td>
                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($c->city->name); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($u->completed ? "Si" : "No"); ?></td>
                                    <td><?php echo e($u->visible ? "Si" : "No"); ?></td>
                                    <td><?php echo e($u->online ? "Si" : "No"); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.images.getFilter', ['id'=> $u->id, 'name' => $u->full_name, 'filter' => 'todas'])); ?>" style="font-size: 18px; color:black;">
                                            <i class="fa-solid fa-image"></i>
                                        </a>
                                        <a href="#" data-toggle="modal" data-target="#ver-perfil-<?php echo e($u->id); ?>" style="font-size: 18px; color:black;">
                                            <i class="fa-solid fa-user"></i>
                                        </a>
                                        <a href="#" style="font-size: 18px; color:black;">
                                            <i class="fa-solid fa-euro-sign"></i>
                                        </a>
                                        <a href="#" data-toggle="modal" data-target="#editar-status-<?php echo e($u->id); ?>" style="font-size: 18px; color:black;">
                                            <i class="fa-solid fa-pen"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php echo $__env->make('modals.admin.modal_ver_perfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('modals.admin.user.modal_editar_status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/41031227.servicio-online.net/hotspania.es/resources/views/admin/users/pending.blade.php ENDPATH**/ ?>