@extends('layouts.admin')
@section('title') Inicio @endsection
@section('content')
@include('partial_msg')
arg
@endsection